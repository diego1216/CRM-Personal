export interface ScheduledEvent {
  id: string;
  contactName: string;
  date: string; 
  priorityColor: string; 
}
